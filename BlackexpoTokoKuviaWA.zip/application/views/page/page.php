<div class="title">
    <h2 style="text-transform: uppercase;"><?= $page['title']; ?></h2>
</div>

<div class="wrapper">
    <?= $page['content']; ?>
</div>